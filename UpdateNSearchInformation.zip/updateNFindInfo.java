import java.io.*;
import java.sql.*;
import org.sqlite.SQLiteConfig;
import java.util.*;
import javax.swing.*;
public class updateNFindInfo {

//This code is based upon our previous Java assignment "Tidbok".
public static final String DB_URL = "jdbc:sqlite:testdatabase/fitnessab.db";  
public static final String DRIVER = "org.sqlite.JDBC";  

public static void main(String[] args) throws IOException {
Connection conn = null;

choice();
}

public static void choice() throws IOException
 {
      
       String in = "";                      
       String[] options = new String[] {"Quit", "Find", "Update", "List"};
       String title = "Choose one of these operations:";
       String message = "List - Show all members in the database \n" + 
       "Update - Update personal information\n" + "Find - Find information about customers\n"
        + "Quit - Exit program\n";
       int choice = JOptionPane.showOptionDialog(null, //Component parentComponent
                                  message, //Object message,
                                  title, //String titleden 
                                  JOptionPane.YES_NO_OPTION, //int optionType
                                  JOptionPane.QUESTION_MESSAGE, //int messageType
                                  null, //Icon icon,
                                  options, //Object[] options,
                                  null);//Object initialValue 
       if (choice==0) System.exit(0);
       if (choice==1) alloperations(1);
       if (choice==2) alloperations(2);
       if (choice==3) alloperations(3);
       
       
       
       
       
 
 
 }
 public static void alloperations(int xox) throws IOException
 {
      Connection conn = null;
      try {
      Class.forName(DRIVER);
      SQLiteConfig config = new SQLiteConfig();  
      config.enforceForeignKeys(true); // Denna kodrad ser till att s�tta databasen i ett l�ge d�r den ger felmeddelande ifall man bryter mot n�gon fr�mmande-nyckel-regel
      conn = DriverManager.getConnection(DB_URL,config.toProperties());  
      } catch (Exception e) {
      // Om java-progammet inte lyckas koppla upp sig mot databasen (t ex om fel s�kv�g eller om driver inte hittas) s� kommer ett felmeddelande skrivas ut
      System.out.println( e.toString() );
      System.exit(0);
      }
      
        
      Scanner input = new Scanner(System.in);
      long PNr;
      String FNamn;
      String ENamn;
      String antalTimmar;
      String Datum;
      String inDatum;
      String inDatum2;
      String inDatum3;
      
      String res1, res2, res3, res4, res5, res6 = "";
      
      PreparedStatement fr�ga;
      ResultSet resultat;
      String in = "";
      if (xox==3) in = "ALL";
      if (xox==2) in = "NEW";
      if (xox==1) in = "A";
      
      try { 
      switch (in) { 
            
    
            
      case "A":
      String[] options3 = new String[] {"Q", "LN", "FN", "PN", "MI"};
          String title3 = "Choose one of these operations:";
          String message3 = "MI - find someone through their memberID\n" 
           + "PN - find someone through their person number\n"  
          + "FN - find someone through their first name\n" + "LN - Find someone through their Last name\n"
           + "Q - Exit program";
          int choice3 = JOptionPane.showOptionDialog(null, //Component parentComponent
                                     message3, //Object message,
                                     title3, //String titleden 
                                     JOptionPane.YES_NO_OPTION, //int optionType
                                     JOptionPane.QUESTION_MESSAGE, //int messageType
                                     null, //Icon icon,
                                     options3, //Object[] options,
                                     null);//Object initialValue 
          if (choice3==0) System.exit(0);
          if (choice3==1)
          {
            String lastsearch = JOptionPane.showInputDialog("What is their last name?:");
            fr�ga = conn.prepareStatement("select * from member where lName='"+lastsearch+"'");
            resultat = fr�ga.executeQuery(); 
            while (resultat.next()) 
            { 
            res1= resultat.getString(1);
            res2 = resultat.getString(2);
            res3 = resultat.getString(3);
            res4 = resultat.getString(4);
            res5 = resultat.getString(5);
            res6 = resultat.getString(6);
            String testres = "First name: " + res6 + "\nLast name: " + res5 + "\nMemberID: " + res1 + "\nPersonal number: " + res2 + "\nEmail: " + res4 + "\nPhone number: " + res3;
            
            JOptionPane.showMessageDialog(null, testres); 
            }
            
          }
          if (choice3==2)
          {
            String firstsearch = JOptionPane.showInputDialog("What is their first name?:");
            fr�ga = conn.prepareStatement("select * from member where fName='"+firstsearch+"'");
            resultat = fr�ga.executeQuery(); 
            while (resultat.next()) 
            { 
            res1= resultat.getString(1);
            res2 = resultat.getString(2);
            res3 = resultat.getString(3);
            res4 = resultat.getString(4);
            res5 = resultat.getString(5);
            res6 = resultat.getString(6);
            String testres = "First name: " + res6 + "\nLast name: " + res5 + "\nMemberID: " + res1 + "\nPersonal number: " + res2 + "\nEmail: " + res4 + "\nPhone number: " + res3;
            
            JOptionPane.showMessageDialog(null, testres);
            }
            
          }
          if (choice3==3)
          {
            String personnsearch = JOptionPane.showInputDialog("What is their personal number?:");
            fr�ga = conn.prepareStatement("select * from member where pNr='"+personnsearch+"'");
            resultat = fr�ga.executeQuery(); 
            while (resultat.next()) 
            { 
            res1= resultat.getString(1);
            res2 = resultat.getString(2);
            res3 = resultat.getString(3);
            res4 = resultat.getString(4);
            res5 = resultat.getString(5);
            res6 = resultat.getString(6);
            String testres = "First name: " + res6 + "\nLast name: " + res5 + "\nMemberID: " + res1 + "\nPersonal number: " + res2 + "\nEmail: " + res4 + "\nPhone number: " + res3;
            
            JOptionPane.showMessageDialog(null, testres);
           

            }
            
          }
          if (choice3==4)
          {
            String memberIsearch = JOptionPane.showInputDialog("What is their memberID?:");
            fr�ga = conn.prepareStatement("select * from member where memberID='"+memberIsearch+"'");
            resultat = fr�ga.executeQuery(); 
            while (resultat.next()) 
            { 
            res1= resultat.getString(1);
            res2 = resultat.getString(2);
            res3 = resultat.getString(3);
            res4 = resultat.getString(4);
            res5 = resultat.getString(5);
            res6 = resultat.getString(6);
            String testres = "First name: " + res6 + "\nLast name: " + res5 + "\nMemberID: " + res1 + "\nPersonal number: " + res2 + "\nEmail: " + res4 + "\nPhone number: " + res3;
            
            JOptionPane.showMessageDialog(null, testres);
           
           // System.out.println(res1 + "\t" + res2 + "\t" + res3 + "\t" + res4 + "\t" + res5 + "\t" + res6  + "\n"); 
            }
            
          }
      
    
      break; 
            
      case "Q":
      System.exit(0);
      break; 
       case "ALL":
           
            fr�ga = conn.prepareStatement("select * from member");
            resultat = fr�ga.executeQuery(); 
            while (resultat.next()) 
            { 
            res1= resultat.getString(1);
            res2 = resultat.getString(2);
            res3 = resultat.getString(3);
            res4 = resultat.getString(4);
            res5 = resultat.getString(5);
            res6 = resultat.getString(6);
            String testres = "First name: " + res6 + "\nLast name: " + res5 + "\nMemberID: " + res1 + "\nPersonal number: " + res2 + "\nEmail: " + res4 + "\nPhone number: " + res3 + "\n \n";
            
            System.out.println(testres);
           
           // System.out.println(res1 + "\t" + res2 + "\t" + res3 + "\t" + res4 + "\t" + res5 + "\t" + res6  + "\n"); 
            }
            
          
      break;
      
      case "NEW":
        
         String personnumberS = JOptionPane.showInputDialog("Please enter your 10 digit personal number: ");
         double personnumberI = Double.parseDouble(personnumberS);
         
          String in2 = "";                      
          String[] options2 = new String[] {"Q", "PW", "EM", "PN", "EN", "FN"};
          String title2 = "Choose one of these operations:";
          String message2 = "FN - Change first name\n" + 
          "EN - Change last name\n" + "PN - Change phone number\n"  
          + "EM - Change email adress\n" + "PW - Change password\n"
           + "Q - Exit program";
          int choice2 = JOptionPane.showOptionDialog(null, //Component parentComponent
                                     message2, //Object message,
                                     title2, //String titleden 
                                     JOptionPane.YES_NO_OPTION, //int optionType
                                     JOptionPane.QUESTION_MESSAGE, //int messageType
                                     null, //Icon icon,
                                     options2, //Object[] options,
                                     null);//Object initialValue 
          if (choice2==0) System.exit(0);
          if (choice2==1)
          {
            String password = JOptionPane.showInputDialog("What would you like to change your password to?: ");
            fr�ga = conn.prepareStatement("UPDATE member SET password='" + password + "' WHERE pNr='" + personnumberI + "'");
            fr�ga.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Change has been registered");
          }
          if (choice2==2) 
          {
            
            String emailc = JOptionPane.showInputDialog("What would you like to change your email to?: ");
            fr�ga = conn.prepareStatement("UPDATE member SET email='" + emailc + "' WHERE pNr='" + personnumberI + "'");
            fr�ga.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Change has been registered");
          }
          if (choice2==3) 
          {
            String addressc = JOptionPane.showInputDialog("What would you like to change your phone number to?: ");
            int phonenumb = Integer.parseInt(addressc);
            fr�ga = conn.prepareStatement("UPDATE member SET phone='" + phonenumb + "' WHERE pNr='" + personnumberI + "'");
            fr�ga.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Change has been registered");          }
          if (choice2==4)
          {
            String lastnamec = JOptionPane.showInputDialog("What would you like to change your last name to?: ");
            fr�ga = conn.prepareStatement("UPDATE member SET lName='" + lastnamec + "' WHERE pNr='" + personnumberI + "'");
            fr�ga.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Change has been registered");          }
          if (choice2==5)
          {
            String firstnamec = JOptionPane.showInputDialog("What would you like to change your first name to?: ");
            fr�ga = conn.prepareStatement("UPDATE member SET fName='" + firstnamec + "' WHERE pNr='" + personnumberI + "'");
            fr�ga.executeUpdate();
            JOptionPane.showMessageDialog(null, "Your Change has been registered");
          }
          
      break;
      
     
      
          
          }
         
         }
        catch (SQLException e) 
        { 
         System.out.println("Something went wrong: ");
      
            
      

        }
 choice();
 }
 
}